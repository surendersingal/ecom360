/**
 * Ecom360 Analytics — Client-Side Tracking SDK
 *
 * Reads configuration from the <script id="ecom360-config"> JSON block
 * injected by the PHP tracker class and automatically captures:
 *   page_view, product_view, search, scroll_depth, engagement_time
 *
 * Cart / checkout / purchase events are sent from either the WooCommerce
 * server-side hooks (class-ecom360-woocommerce.php) or the companion
 * ecom360-wc.js script for AJAX-driven storefronts.
 *
 * @version 1.0.0
 */
;(function () {
    'use strict';

    /* ═══════════════════════════ Bootstrap ════════════════════════════ */

    const cfgEl = document.getElementById('ecom360-config');
    if (!cfgEl) return;

    let parsed;
    try { parsed = JSON.parse(cfgEl.textContent); } catch (e) { return; }

    const C      = parsed.config  || {};
    const events = parsed.events  || {};
    const page   = parsed.page    || {};

    if (!C.endpoint || !C.apiKey) return;

    const COLLECT_URL = C.endpoint.replace(/\/$/, '') + '/api/v1/collect';
    const BATCH_URL   = C.endpoint.replace(/\/$/, '') + '/api/v1/collect/batch';

    /* ═══════════════════════════ Session ══════════════════════════════ */

    const SESSION_KEY    = 'ecom360_sid';
    const SESSION_TS_KEY = 'ecom360_sid_ts';
    const SESSION_TIMEOUT = (C.sessionTimeout || 30) * 60 * 1000; // ms

    function getSessionId() {
        let sid = getCookie(SESSION_KEY);
        let ts  = parseInt(getCookie(SESSION_TS_KEY) || '0', 10);
        const now = Date.now();

        if (!sid || (now - ts) > SESSION_TIMEOUT) {
            sid = 'js_' + uuid();
            setCookie(SESSION_KEY, sid, 365);
        }
        setCookie(SESSION_TS_KEY, String(now), 365);
        return sid;
    }

    /* ═══════════════════════════ Helpers ══════════════════════════════ */

    function uuid() {
        if (crypto && crypto.randomUUID) return crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = (Math.random() * 16) | 0;
            return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
        });
    }

    function getCookie(name) {
        const m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : null;
    }

    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + days * 86400000);
        document.cookie = name + '=' + encodeURIComponent(value) + ';path=/;expires=' + d.toUTCString() + ';SameSite=Lax';
    }

    /* ═══════════════════════════ UTM ══════════════════════════════════ */

    function getUtm() {
        if (!C.captureUtm) return null;
        const params = new URLSearchParams(location.search);
        const utm = {};
        let found = false;
        ['source', 'medium', 'campaign', 'term', 'content'].forEach(function (k) {
            const v = params.get('utm_' + k);
            if (v) { utm[k] = v; found = true; }
        });
        return found ? utm : null;
    }

    /* ═══════════════════════════ Fingerprint ══════════════════════════ */

    function getFingerprint() {
        if (!C.enableFingerprint) return null;

        // Lightweight canvas + UA fingerprint (non-PII)
        const fp_key = 'ecom360_fp';
        let fp = getCookie(fp_key);
        if (fp) return fp;

        const parts = [
            navigator.userAgent,
            navigator.language,
            screen.colorDepth,
            screen.width + 'x' + screen.height,
            new Date().getTimezoneOffset(),
            navigator.hardwareConcurrency || 0,
            navigator.deviceMemory || 0,
        ];

        // Simple hash
        let hash = 0;
        const str = parts.join('|');
        for (let i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash + str.charCodeAt(i)) | 0;
        }
        fp = 'fp_' + Math.abs(hash).toString(36);
        setCookie(fp_key, fp, 365);
        return fp;
    }

    /* ═══════════════════════════ Event Queue ══════════════════════════ */

    const queue = [];
    let flushTimer = null;

    function buildEvent(eventType, metadata) {
        const evt = {
            event_type: eventType,
            url:        page.url || location.href,
            page_title: page.title || document.title,
            session_id: getSessionId(),
            timezone:   Intl.DateTimeFormat().resolvedOptions().timeZone || '',
            language:   navigator.language || '',
            screen_resolution: screen.width + 'x' + screen.height,
        };

        if (metadata && Object.keys(metadata).length) {
            evt.metadata = metadata;
        }

        if (page.customer) {
            evt.customer_identifier = page.customer;
        }

        const referrer = C.captureReferrer ? document.referrer : null;
        if (referrer) evt.referrer = referrer;

        const fp = getFingerprint();
        if (fp) evt.device_fingerprint = fp;

        const utm = getUtm();
        if (utm) evt.utm = utm;

        return evt;
    }

    /**
     * Public API: track an event.
     */
    function track(eventType, metadata) {
        const evt = buildEvent(eventType, metadata || {});

        if (C.batchEvents) {
            queue.push(evt);
            if (queue.length >= (C.batchSize || 10)) {
                flush();
            } else if (!flushTimer) {
                flushTimer = setTimeout(flush, C.flushInterval || 5000);
            }
        } else {
            sendSingle(evt);
        }
    }

    function flush() {
        if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
        if (!queue.length) return;

        const batch = queue.splice(0, 50); // API max = 50
        sendBatch(batch);
    }

    /* ═══════════════════════════ Transport ════════════════════════════ */

    function sendSingle(evt) {
        const body = JSON.stringify(evt);
        if (navigator.sendBeacon) {
            const blob = new Blob([body], { type: 'application/json' });
            // sendBeacon can't set custom headers, fall back to fetch
        }
        fetch(COLLECT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Ecom360-Key': C.apiKey,
            },
            body: body,
            keepalive: true,
        }).catch(function () {});
    }

    function sendBatch(items) {
        const body = JSON.stringify({ events: items });
        fetch(BATCH_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Ecom360-Key': C.apiKey,
            },
            body: body,
            keepalive: true,
        }).catch(function () {});
    }

    /**
     * Use sendBeacon for unload – falls back to query-param auth since
     * sendBeacon cannot set custom headers.
     */
    function sendBeaconSingle(evt) {
        const url = COLLECT_URL + '?api_key=' + encodeURIComponent(C.apiKey);
        const blob = new Blob([JSON.stringify(evt)], { type: 'application/json' });
        navigator.sendBeacon(url, blob);
    }

    function sendBeaconBatch(items) {
        const url = BATCH_URL + '?api_key=' + encodeURIComponent(C.apiKey);
        const blob = new Blob([JSON.stringify({ events: items })], { type: 'application/json' });
        navigator.sendBeacon(url, blob);
    }

    /* ═══════════════════════════ Auto-track: Page View ════════════════ */

    if (events.pageViews) {
        track('page_view', {
            page_type: page.type || 'page',
            category:  page.category || null,
        });
    }

    /* ═══════════════════════════ Auto-track: Product View ═════════════ */

    if (events.products && page.type === 'product' && page.product) {
        track('product_view', page.product);
    }

    /* ═══════════════════════════ Auto-track: Search ═══════════════════ */

    if (events.search) {
        var sp = new URLSearchParams(location.search);
        var searchQuery = sp.get('s') || sp.get('q') || sp.get('search') || sp.get('dgwt_wcas');
        if (searchQuery) {
            track('search', { query: searchQuery });
        }
    }

    /* ═══════════════════════════ Scroll Depth ═════════════════════════ */

    (function () {
        var maxScroll = 0;
        var milestones = [25, 50, 75, 100];
        var reported = {};

        window.addEventListener('scroll', function () {
            var docHeight = Math.max(
                document.body.scrollHeight,
                document.documentElement.scrollHeight
            ) - window.innerHeight;
            if (docHeight <= 0) return;

            var pct = Math.round((window.scrollY / docHeight) * 100);
            if (pct > maxScroll) maxScroll = pct;

            milestones.forEach(function (m) {
                if (pct >= m && !reported[m]) {
                    reported[m] = true;
                    track('scroll_depth', { percent: m });
                }
            });
        }, { passive: true });
    })();

    /* ═══════════════════════════ Engagement Time ══════════════════════ */

    (function () {
        var startTime = Date.now();
        var engaged   = 0;
        var active    = true;

        document.addEventListener('visibilitychange', function () {
            if (document.hidden) {
                if (active) engaged += Date.now() - startTime;
                active = false;
            } else {
                startTime = Date.now();
                active = true;
            }
        });

        // On unload, send engagement + flush queue
        function onUnload() {
            if (active) engaged += Date.now() - startTime;

            var engagementEvt = buildEvent('engagement_time', {
                seconds: Math.round(engaged / 1000),
            });

            // Flush remaining queue + engagement via sendBeacon
            if (queue.length) {
                queue.push(engagementEvt);
                sendBeaconBatch(queue.splice(0, 50));
            } else {
                sendBeaconSingle(engagementEvt);
            }
        }

        window.addEventListener('pagehide', onUnload);
        // Fallback for older browsers
        window.addEventListener('beforeunload', onUnload);
    })();

    /* ═══════════════════════════ Public API ═══════════════════════════ */

    // Expose for use by ecom360-wc.js and custom integrations
    window.ecom360 = {
        track:        track,
        flush:        flush,
        getSessionId: getSessionId,
        buildEvent:   buildEvent,
    };

})();
