<?php
/**
 * Plugin Name:       Ecom360 Analytics
 * Plugin URI:        https://ecom360.io/wordpress
 * Description:       Complete ecommerce analytics tracking for WooCommerce stores. Captures page views, sessions, products, carts, purchases, customer events, and more — sent to your Ecom360 Analytics dashboard.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ecom360
 * Author URI:        https://ecom360.io
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ecom360-analytics
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   9.6
 */

defined('ABSPATH') || exit;

// ─── Constants ───────────────────────────────────────────────────────
define('ECM360_VERSION',      '1.0.0');
define('ECM360_PLUGIN_FILE',  __FILE__);
define('ECM360_PLUGIN_DIR',   plugin_dir_path(__FILE__));
define('ECM360_PLUGIN_URL',   plugin_dir_url(__FILE__));
define('ECM360_OPTION_KEY',   'ecom360_settings');

// ─── Autoload ────────────────────────────────────────────────────────
require_once ECM360_PLUGIN_DIR . 'includes/class-ecom360-settings.php';
require_once ECM360_PLUGIN_DIR . 'includes/class-ecom360-tracker.php';
require_once ECM360_PLUGIN_DIR . 'includes/class-ecom360-woocommerce.php';
require_once ECM360_PLUGIN_DIR . 'includes/class-ecom360-admin.php';
require_once ECM360_PLUGIN_DIR . 'includes/class-ecom360-rest.php';

// ─── Boot ────────────────────────────────────────────────────────────
/**
 * Main plugin class.
 */
final class Ecom360_Analytics {

    /** @var self|null */
    private static $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Admin settings page
        if ( is_admin() ) {
            new Ecom360_Admin();
        }

        // REST API endpoints (for settings test / health check)
        new Ecom360_REST();

        // Frontend tracker & WooCommerce hooks
        add_action( 'wp', [ $this, 'init_tracking' ] );

        // WooCommerce server-side hooks (always loaded if WC is active)
        if ( $this->is_woocommerce_active() ) {
            new Ecom360_WooCommerce();
        }

        // Activation hook
        register_activation_hook( ECM360_PLUGIN_FILE, [ $this, 'activate' ] );
    }

    /**
     * Initialize client-side tracking on front-end pages.
     */
    public function init_tracking(): void {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }

        $settings = Ecom360_Settings::get();
        if ( empty( $settings['api_key'] ) || empty( $settings['endpoint'] ) ) {
            return;
        }

        // Don't track logged-in admins unless they opted in
        if ( current_user_can( 'manage_options' ) && empty( $settings['track_admins'] ) ) {
            return;
        }

        $tracker = new Ecom360_Tracker( $settings );
        $tracker->enqueue();
    }

    /**
     * Check if WooCommerce is active.
     */
    public function is_woocommerce_active(): bool {
        return class_exists( 'WooCommerce' );
    }

    /**
     * Plugin activation: set default options.
     */
    public function activate(): void {
        $defaults = Ecom360_Settings::defaults();
        if ( ! get_option( ECM360_OPTION_KEY ) ) {
            update_option( ECM360_OPTION_KEY, $defaults );
        }
    }
}

// ─── Launch ──────────────────────────────────────────────────────────
add_action( 'plugins_loaded', [ 'Ecom360_Analytics', 'instance' ] );
