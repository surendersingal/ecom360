<?php
/**
 * Settings helper — manages all plugin options.
 *
 * @package Ecom360_Analytics
 */

defined('ABSPATH') || exit;

final class Ecom360_Settings {

    /**
     * Get all settings with defaults merged.
     *
     * @return array<string, mixed>
     */
    public static function get(): array {
        $saved = get_option( ECM360_OPTION_KEY, [] );
        return wp_parse_args( $saved, self::defaults() );
    }

    /**
     * Save all settings.
     *
     * @param array<string, mixed> $settings
     */
    public static function save( array $settings ): void {
        update_option( ECM360_OPTION_KEY, $settings );
    }

    /**
     * Get a single setting value.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    public static function value( string $key, $default = '' ) {
        $settings = self::get();
        return $settings[ $key ] ?? $default;
    }

    /**
     * Default plugin settings.
     *
     * @return array<string, mixed>
     */
    public static function defaults(): array {
        return [
            // Connection
            'endpoint'          => '',
            'api_key'           => '',

            // Event toggles
            'track_page_views'  => '1',
            'track_products'    => '1',
            'track_cart'        => '1',
            'track_checkout'    => '1',
            'track_purchases'   => '1',
            'track_search'      => '1',
            'track_login'       => '1',
            'track_register'    => '1',
            'track_reviews'     => '1',

            // Behavior
            'track_admins'      => '',
            'batch_events'      => '1',
            'batch_size'        => '10',
            'flush_interval'    => '5000', // ms
            'session_timeout'   => '30',   // minutes

            // Identity
            'enable_fingerprint' => '1',
            'capture_utm'        => '1',
            'capture_referrer'   => '1',

            // Status
            'is_connected'       => '',
            'last_test_at'       => '',
        ];
    }
}
