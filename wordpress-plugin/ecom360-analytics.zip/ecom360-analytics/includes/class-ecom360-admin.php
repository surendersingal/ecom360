<?php
/**
 * Admin settings page for Ecom360 Analytics.
 *
 * @package Ecom360_Analytics
 */

defined('ABSPATH') || exit;

final class Ecom360_Admin {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    /* ─────────────────────────── Menu ──────────────────────────────────── */

    public function add_menu(): void {
        // If WooCommerce is active, nest under it; otherwise under Settings
        $parent = class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php';

        add_submenu_page(
            $parent,
            __( 'Ecom360 Analytics', 'ecom360-analytics' ),
            __( 'Ecom360 Analytics', 'ecom360-analytics' ),
            'manage_options',
            'ecom360-analytics',
            [ $this, 'render_page' ]
        );
    }

    /* ─────────────────────────── Assets ────────────────────────────────── */

    public function enqueue_assets( $hook ): void {
        if ( false === strpos( $hook, 'ecom360-analytics' ) ) return;

        wp_enqueue_style(
            'ecom360-admin',
            ECM360_PLUGIN_URL . 'admin/css/admin.css',
            [],
            ECM360_VERSION
        );

        wp_enqueue_script(
            'ecom360-admin',
            ECM360_PLUGIN_URL . 'admin/js/admin.js',
            [ 'jquery' ],
            ECM360_VERSION,
            true
        );

        wp_localize_script( 'ecom360-admin', 'ecom360Admin', [
            'restUrl' => rest_url( 'ecom360/v1/' ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
        ]);
    }

    /* ─────────────────────────── Settings registration ─────────────────── */

    public function register_settings(): void {
        register_setting( 'ecom360_settings', ECM360_OPTION_KEY, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize' ],
        ]);
    }

    /**
     * Sanitize incoming settings.
     *
     * @param  array $input
     * @return array
     */
    public function sanitize( $input ): array {
        $clean = Ecom360_Settings::defaults();

        $clean['endpoint'] = esc_url_raw( $input['endpoint'] ?? '' );
        $clean['api_key']  = sanitize_text_field( $input['api_key'] ?? '' );

        // Checkboxes
        $toggles = [
            'track_page_views', 'track_products', 'track_cart', 'track_checkout',
            'track_purchases', 'track_search', 'track_login', 'track_register',
            'track_reviews', 'track_admins', 'batch_events', 'enable_fingerprint',
            'capture_utm', 'capture_referrer',
        ];
        foreach ( $toggles as $key ) {
            $clean[ $key ] = ! empty( $input[ $key ] );
        }

        // Numeric
        $clean['batch_size']       = absint( $input['batch_size'] ?? 10 );
        $clean['flush_interval']   = absint( $input['flush_interval'] ?? 5000 );
        $clean['session_timeout']  = absint( $input['session_timeout'] ?? 30 );

        // Preserve connection-test status
        $existing = Ecom360_Settings::get();
        $clean['is_connected'] = $existing['is_connected'] ?? false;
        $clean['last_test_at'] = $existing['last_test_at'] ?? '';

        return $clean;
    }

    /* ─────────────────────────── Page renderer ──────────────────────────── */

    public function render_page(): void {
        $s = Ecom360_Settings::get();
        ?>
        <div class="wrap ecom360-wrap">
            <h1>
                <span class="ecom360-logo">📊</span>
                <?php esc_html_e( 'Ecom360 Analytics', 'ecom360-analytics' ); ?>
            </h1>

            <!-- Connection status banner -->
            <div id="ecom360-status" class="ecom360-status <?php echo $s['is_connected'] ? 'connected' : 'disconnected'; ?>">
                <span class="indicator"></span>
                <span class="label">
                    <?php echo $s['is_connected']
                        ? esc_html__( 'Connected', 'ecom360-analytics' )
                        : esc_html__( 'Not connected', 'ecom360-analytics' ); ?>
                </span>
                <?php if ( $s['last_test_at'] ): ?>
                    <small>— <?php printf( esc_html__( 'last checked %s', 'ecom360-analytics' ), esc_html( $s['last_test_at'] ) ); ?></small>
                <?php endif; ?>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields( 'ecom360_settings' ); ?>

                <!-- ═══ Connection ═══ -->
                <div class="ecom360-card">
                    <h2><?php esc_html_e( 'Connection', 'ecom360-analytics' ); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><label for="endpoint"><?php esc_html_e( 'API Endpoint', 'ecom360-analytics' ); ?></label></th>
                            <td>
                                <input type="url" id="endpoint" name="<?php echo ECM360_OPTION_KEY; ?>[endpoint]"
                                       value="<?php echo esc_attr( $s['endpoint'] ); ?>" class="regular-text"
                                       placeholder="https://analytics.example.com">
                                <p class="description"><?php esc_html_e( 'Your Ecom360 platform URL (without /api path).', 'ecom360-analytics' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="api_key"><?php esc_html_e( 'API Key', 'ecom360-analytics' ); ?></label></th>
                            <td>
                                <input type="password" id="api_key" name="<?php echo ECM360_OPTION_KEY; ?>[api_key]"
                                       value="<?php echo esc_attr( $s['api_key'] ); ?>" class="regular-text"
                                       autocomplete="off">
                                <button type="button" id="ecom360-test-connection" class="button button-secondary">
                                    <?php esc_html_e( 'Test Connection', 'ecom360-analytics' ); ?>
                                </button>
                                <span id="ecom360-test-result"></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ═══ Event Tracking ═══ -->
                <div class="ecom360-card">
                    <h2><?php esc_html_e( 'Event Tracking', 'ecom360-analytics' ); ?></h2>
                    <table class="form-table">
                        <?php
                        $events = [
                            'track_page_views' => __( 'Page Views', 'ecom360-analytics' ),
                            'track_products'   => __( 'Product Views', 'ecom360-analytics' ),
                            'track_cart'       => __( 'Cart Events (add / remove / abandoned)', 'ecom360-analytics' ),
                            'track_checkout'   => __( 'Checkout Events', 'ecom360-analytics' ),
                            'track_purchases'  => __( 'Purchases & Orders', 'ecom360-analytics' ),
                            'track_search'     => __( 'Site Search', 'ecom360-analytics' ),
                            'track_login'      => __( 'User Login', 'ecom360-analytics' ),
                            'track_register'   => __( 'User Registration', 'ecom360-analytics' ),
                            'track_reviews'    => __( 'Product Reviews', 'ecom360-analytics' ),
                        ];
                        foreach ( $events as $key => $label ): ?>
                            <tr>
                                <th><?php echo esc_html( $label ); ?></th>
                                <td>
                                    <label class="ecom360-toggle">
                                        <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[<?php echo $key; ?>]" value="0">
                                        <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[<?php echo $key; ?>]"
                                               value="1" <?php checked( $s[ $key ] ); ?>>
                                        <span class="slider"></span>
                                    </label>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>

                <!-- ═══ Behavior ═══ -->
                <div class="ecom360-card">
                    <h2><?php esc_html_e( 'Behavior', 'ecom360-analytics' ); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php esc_html_e( 'Track Admin Users', 'ecom360-analytics' ); ?></th>
                            <td>
                                <label class="ecom360-toggle">
                                    <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[track_admins]" value="0">
                                    <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[track_admins]"
                                           value="1" <?php checked( $s['track_admins'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description"><?php esc_html_e( 'When disabled, logged-in administrators are excluded.', 'ecom360-analytics' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Batch Events', 'ecom360-analytics' ); ?></th>
                            <td>
                                <label class="ecom360-toggle">
                                    <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[batch_events]" value="0">
                                    <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[batch_events]"
                                           value="1" <?php checked( $s['batch_events'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description"><?php esc_html_e( 'Queue events and send in batches to reduce HTTP requests.', 'ecom360-analytics' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="batch_size"><?php esc_html_e( 'Batch Size', 'ecom360-analytics' ); ?></label></th>
                            <td>
                                <input type="number" id="batch_size" name="<?php echo ECM360_OPTION_KEY; ?>[batch_size]"
                                       value="<?php echo esc_attr( $s['batch_size'] ); ?>" min="1" max="50" class="small-text">
                                <p class="description"><?php esc_html_e( 'Max events per batch request (API limit: 50).', 'ecom360-analytics' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="flush_interval"><?php esc_html_e( 'Flush Interval (ms)', 'ecom360-analytics' ); ?></label></th>
                            <td>
                                <input type="number" id="flush_interval" name="<?php echo ECM360_OPTION_KEY; ?>[flush_interval]"
                                       value="<?php echo esc_attr( $s['flush_interval'] ); ?>" min="1000" max="60000" step="1000" class="small-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="session_timeout"><?php esc_html_e( 'Session Timeout (min)', 'ecom360-analytics' ); ?></label></th>
                            <td>
                                <input type="number" id="session_timeout" name="<?php echo ECM360_OPTION_KEY; ?>[session_timeout]"
                                       value="<?php echo esc_attr( $s['session_timeout'] ); ?>" min="5" max="120" class="small-text">
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ═══ Identity & Privacy ═══ -->
                <div class="ecom360-card">
                    <h2><?php esc_html_e( 'Identity & Privacy', 'ecom360-analytics' ); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th><?php esc_html_e( 'Device Fingerprinting', 'ecom360-analytics' ); ?></th>
                            <td>
                                <label class="ecom360-toggle">
                                    <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[enable_fingerprint]" value="0">
                                    <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[enable_fingerprint]"
                                           value="1" <?php checked( $s['enable_fingerprint'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                                <p class="description"><?php esc_html_e( 'Generate a lightweight browser fingerprint for cross-session identification.', 'ecom360-analytics' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Capture UTM Parameters', 'ecom360-analytics' ); ?></th>
                            <td>
                                <label class="ecom360-toggle">
                                    <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[capture_utm]" value="0">
                                    <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[capture_utm]"
                                           value="1" <?php checked( $s['capture_utm'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Capture Referrer', 'ecom360-analytics' ); ?></th>
                            <td>
                                <label class="ecom360-toggle">
                                    <input type="hidden" name="<?php echo ECM360_OPTION_KEY; ?>[capture_referrer]" value="0">
                                    <input type="checkbox" name="<?php echo ECM360_OPTION_KEY; ?>[capture_referrer]"
                                           value="1" <?php checked( $s['capture_referrer'] ); ?>>
                                    <span class="slider"></span>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button( __( 'Save Settings', 'ecom360-analytics' ) ); ?>
            </form>
        </div>
        <?php
    }
}
