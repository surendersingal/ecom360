<?php
/**
 * WP REST API endpoints for Ecom360 (settings page AJAX).
 *
 * @package Ecom360_Analytics
 */

defined('ABSPATH') || exit;

final class Ecom360_Rest {

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        register_rest_route( 'ecom360/v1', '/test-connection', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'test_connection' ],
            'permission_callback' => [ $this, 'admin_check' ],
        ]);

        register_rest_route( 'ecom360/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_status' ],
            'permission_callback' => [ $this, 'admin_check' ],
        ]);
    }

    public function admin_check(): bool {
        return current_user_can( 'manage_options' );
    }

    /**
     * POST /wp-json/ecom360/v1/test-connection
     *
     * Sends a lightweight test event to the ecom360 backend and reports success / failure.
     */
    public function test_connection( \WP_REST_Request $request ): \WP_REST_Response {
        $settings = Ecom360_Settings::get();
        $endpoint = rtrim( $settings['endpoint'], '/' ) . '/api/v1/collect';
        $api_key  = $settings['api_key'];

        if ( empty( $endpoint ) || empty( $api_key ) ) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __( 'Please enter an API endpoint and key first.', 'ecom360-analytics' ),
            ], 400 );
        }

        $payload = [
            'event_type' => 'connection_test',
            'url'        => home_url(),
            'session_id' => 'wp_test_' . wp_generate_uuid4(),
            'metadata'   => [
                'plugin_version' => ECM360_VERSION,
                'wp_version'     => get_bloginfo( 'version' ),
                'wc_version'     => defined( 'WC_VERSION' ) ? WC_VERSION : 'n/a',
                'php_version'    => phpversion(),
                'site_url'       => home_url(),
            ],
        ];

        $response = wp_remote_post( $endpoint, [
            'timeout' => 15,
            'headers' => [
                'Content-Type'  => 'application/json',
                'X-Ecom360-Key' => $api_key,
                'Accept'        => 'application/json',
            ],
            'body'        => wp_json_encode( $payload ),
            'data_format' => 'body',
        ]);

        if ( is_wp_error( $response ) ) {
            $this->save_test_result( false );
            return new \WP_REST_Response([
                'success' => false,
                'message' => $response->get_error_message(),
            ], 502 );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code >= 200 && $code < 300 ) {
            $this->save_test_result( true );
            return new \WP_REST_Response([
                'success' => true,
                'message' => __( 'Connected successfully!', 'ecom360-analytics' ),
                'tenant'  => $body['tenant'] ?? null,
            ]);
        }

        $this->save_test_result( false );
        $msg = $body['message'] ?? wp_remote_retrieve_response_message( $response );
        return new \WP_REST_Response([
            'success' => false,
            'message' => sprintf( __( 'Server returned %d: %s', 'ecom360-analytics' ), $code, $msg ),
        ], $code );
    }

    /**
     * GET /wp-json/ecom360/v1/status
     */
    public function get_status( \WP_REST_Request $request ): \WP_REST_Response {
        $settings = Ecom360_Settings::get();
        return new \WP_REST_Response([
            'is_connected' => ! empty( $settings['is_connected'] ),
            'last_test_at' => $settings['last_test_at'] ?? '',
            'version'      => ECM360_VERSION,
            'wc_active'    => class_exists( 'WooCommerce' ),
        ]);
    }

    /**
     * Persist the test result.
     */
    private function save_test_result( bool $connected ): void {
        $settings = Ecom360_Settings::get();
        $settings['is_connected'] = $connected;
        $settings['last_test_at'] = wp_date( 'Y-m-d H:i:s' );
        Ecom360_Settings::save( $settings );
    }
}
